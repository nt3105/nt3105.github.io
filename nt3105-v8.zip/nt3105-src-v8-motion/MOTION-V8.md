# NTJR Motion — bản 8

Thiết kế lại chuyển động toàn trang theo yêu cầu mới nhất, giữ nội dung, ảnh, liên kết, giao diện menu và các chức năng hiện có. Bản 7 bám nguyên mẫu Titanium vẫn được giữ riêng; bản 8 phát triển nhịp chuyển động mới.

## Chuyển động

- Hero xuất hiện theo nhịp: nhãn, lời chào/tên, phần giới thiệu và các hành động. Khung ảnh đi vào nhẹ; engine nghiêng theo chuột/cảm biến và thẻ Hello world/nhạc vẫn ở các lớp độc lập.
- Tiêu đề ghép ký tự tiếng Việt với dịch chuyển, góc nghiêng nhỏ và giảm độ mờ; dùng grapheme để giữ dấu. Giữ thẻ xuống dòng, sắc chữ và tên truy cập.
- Nội dung đi lên, ảnh đi từ hai phía, nhóm card stagger có giới hạn độ trễ để không bắt chờ lâu.
- Đường phân cách có vệt sáng; underline mở rộng; thanh kỹ năng chạy đến đúng giá trị hiện có. Thanh đọc trang cập nhật bằng transform.
- Reveal là animation hữu hạn, nội dung mặc định vẫn hiện. Cơ chế tái kích hoạt dùng vùng đệm khi ra khỏi viewport để hạn chế nhấp nháy ở ranh giới.
- Nút có một lớp thu/phóng khi nhấn; phản hồi chọn trong menu game, đổi theme và mở dialog dùng cùng nhịp. Không thêm mục menu hay đổi chức năng nút.
- Giữ khối highlight điều hướng trượt liên tục 480 ms. Giữ xử lý hash, scrollspy và bố cục mobile bốn mục chữ.
- Reduced Motion/chế độ ít hiệu ứng, tab nền, focus bàn phím và thay đổi kích thước được xử lý trong mã. Không đặt vòng lặp animation JavaScript chạy liên tục lúc đứng yên.

## Xung đột xử lý trong mã

- Bỏ hai lớp scale chồng nhau trên nút.
- Bỏ reveal tên hero và transform gallery cũ đã được thay.
- Bổ sung reduced motion cho menu game vốn là div.
- Làm mới vị trí vùng nghiêng sau reveal và khi cuộn gallery ngang; không bắt tilt khi khung đang chạy reveal.

## File thay đổi

`titanium-scroll-effects.js`, `titanium-scroll-site.js`, `titanium-scroll-effects.css`, `enhance.js`, `enhance.css`, `style.css`, `selected.css`, `ios-effects.js`, `ios-effects.css`, `game-menu.css`, `appearance.css`.

Tài liệu: README.md và MOTION-V8.md. Không đổi dữ liệu hoặc nội dung HTML trong index.html.

## Trạng thái bàn giao

Theo yêu cầu đã có trong cuộc trò chuyện: không mở trình duyệt, không chạy website, không build hoặc chạy quy trình kiểm thử cho bản 8. Vì vậy đây là bản code mới để bạn tự sử dụng, không phải bản đã nghiệm thu trên thiết bị. Các kết quả test cũ trong thư mục tests là lịch sử, không xác nhận hành vi bản 8.

ZIP được gửi qua nhánh tải riêng trên GitHub theo sự đồng ý của bạn. Không merge vào main, không deploy hoặc cập nhật website đang hoạt động.

Website là HTML/CSS/JavaScript tĩnh, không cần biên dịch. Nếu muốn chạy cục bộ, giải nén rồi chạy `python3 dev_server.py --port 8000` trong thư mục source và mở `http://127.0.0.1:8000/?intro=off` trên máy đó.
