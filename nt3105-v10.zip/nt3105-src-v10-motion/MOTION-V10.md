# NTJR Motion — bản 10

Chỉ chỉnh chiều cuộn lên theo phản hồi; giữ nguyên keyframe, thời lượng và độ trễ cuộn xuống của bản 9. Không đổi nội dung, bố cục, menu hoặc chức năng.

- Bộ nhận hướng tích lũy khoảng cuộn 6 px để bỏ qua rung nhỏ; không lấy cuộn ngang của gallery làm hướng cuộn trang.
- Hướng được ghi riêng tại lúc mỗi phần bắt đầu xuất hiện. Đổi hướng vuốt giữa chừng không thay keyframe hoặc chạy lại animation đang diễn ra.
- Khi cuộn lên, thẻ đi vào từ phía trên với góc nghiêng nhẹ hơn; tiêu đề mở từ trên với góc 45 độ. Nhịp trở lại 900 ms, độ trễ nhóm tối đa 110 ms, độ trễ ký tự bằng 55% bản cuộn xuống.
- Ảnh mở mặt nạ từ dưới lên; đường gạch tiêu đề mở từ bên phải. Chiều sâu liên tục theo cuộn và tương tác nghiêng ở bản 9 được giữ nguyên.
- Đổi khóa cache riêng hai file motion thành motion-10 ở cả đường vào trực tiếp và qua intro.
- Vẫn tôn trọng Reduced Motion, chế độ ít hiệu ứng, tab nền và focus bàn phím.

File mã thay đổi: titanium-scroll-effects.js, titanium-scroll-effects.css, index.html, intro-3d-demo.html. Tài liệu: README.md và MOTION-V10.md.

Chưa chạy website, build, trình duyệt hoặc kiểm thử bản này theo yêu cầu trước của bạn. Mô tả trên là thay đổi trong mã, chưa phải kết quả xác nhận trên thiết bị.

ZIP là source đầy đủ. Nhánh tải chỉ chứa ZIP và README; không cập nhật nhánh website hoặc deploy. Cần giải nén và sử dụng source mới để thấy thay đổi.
