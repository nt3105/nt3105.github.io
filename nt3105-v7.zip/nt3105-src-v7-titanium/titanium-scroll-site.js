/* Map the existing site to the supplied Titanium reference. No animation engine here. */
(() => {
  'use strict';
  const main = document.querySelector('main');
  if (!main || main.dataset.tsmMapped === 'yes') return;
  main.dataset.tsmMapped = 'yes';

  // Split only text runs, preserving existing <br>, gradient/accent spans and headings.
  main.querySelectorAll('h2').forEach(heading => {
    if (!heading.hasAttribute('aria-label')) {
      const label = heading.cloneNode(true);
      label.querySelectorAll('br').forEach(br => br.replaceWith(' '));
      heading.setAttribute('aria-label', label.textContent.replace(/\s+/g, ' ').trim());
    }
    const nodes = [], walker = document.createTreeWalker(heading, NodeFilter.SHOW_TEXT);
    let text;
    while ((text = walker.nextNode())) if (text.textContent.trim()) nodes.push(text);
    nodes.forEach(node => {
      // A custom inline tag avoids changing existing h2 > span color selectors.
      const copy = document.createElement('tsm-text');
      copy.className = 'tsm-copy';
      copy.setAttribute('data-tsm-kinetic', '');
      node.replaceWith(copy); copy.append(node);
    });
  });

  // Preserve normal word wrapping after the reference splits each text run.
  // Letter order, --letterdelay and --letterx still come entirely from the reference.
  document.addEventListener('tsm:split-ready', () => {
    main.querySelectorAll('.tsm-copy').forEach(copy => {
      const fragment = document.createDocumentFragment();
      let word = null;
      [...copy.children].forEach(letter => {
        if (/^\s+$/.test(letter.textContent)) {
          word = null;
          letter.classList.add('tsm-space');
          letter.textContent = letter.textContent.replace(/\u00a0/g, ' ');
          fragment.append(letter);
        } else {
          if (!word) { word = document.createElement('tsm-word'); word.className = 'tsm-word'; fragment.append(word); }
          word.append(letter);
        }
      });
      copy.append(fragment);
    });
  }, { once:true });

  function reveal(element, direction = 'up') {
    if (element && !element.hasAttribute('data-tsm-reveal')) element.setAttribute('data-tsm-reveal', direction);
  }
  // Use the existing outer tilt shells; never overwrite the pointer/sensor transform.
  main.querySelectorAll('.reveal').forEach(element => {
    if (element.matches('h1,h2') || element.querySelector('h1,h2')) return;
    reveal(element, element.querySelector('.nt-hero-scene') ? 'right' : 'up');
  });
  main.querySelectorAll('.hero-description,.about-content>p,.about-statement>p,.journey-intro>p:not(.eyebrow),.contact-copy>p:not(.eyebrow),.donate-copy>p:not(.eyebrow),.nt-gallery-actions>p').forEach(element => {
    if (!element.closest('[data-tsm-reveal]')) reveal(element);
  });
  main.querySelectorAll('.eyebrow,.nt-gallery-note').forEach(element => {
    if (!element.closest('[data-tsm-reveal]')) reveal(element, 'left');
  });
  main.querySelectorAll('.split-heading>p,.qr-panel').forEach(element => reveal(element, 'right'));
  main.querySelectorAll('.skills-grid,.projects-grid,.social-grid,.life-grid,.timeline,.nt-gallery').forEach(group => {
    [...group.children].forEach((element, index) => {
      reveal(element);
      element.style.setProperty('--stagger', index * 110 + 'ms');
      if (group.matches('.projects-grid,.nt-gallery')) element.setAttribute('data-tsm-reveal', index % 2 ? 'right' : 'left');
    });
  });

  // Reuse separator positions; added decorative spans take no layout space.
  main.querySelectorAll('.section-heading h2').forEach(heading => {
    heading.classList.add('tsm-heading-sweep');
    const sweep = document.createElement('span'); sweep.className = 'tsm-sweep';
    sweep.setAttribute('aria-hidden', 'true'); heading.append(sweep);
  });
  main.querySelectorAll('.section').forEach(section => {
    section.classList.add('tsm-section');
    const line = document.createElement('span'); line.className = 'tsm-drawline';
    line.setAttribute('data-tsm-line', ''); line.setAttribute('aria-hidden', 'true');
    section.append(line);
  });
  // Keep the site's --level widths and skill values; the supplied scale reaches 1.
  main.querySelectorAll('.skill-card .progress').forEach(bar => bar.classList.add('tsm-meter'));
  const progress = document.createElement('div');
  progress.className = 'tsm-scroll-progress'; progress.setAttribute('aria-hidden', 'true');
  progress.append(document.createElement('span')); document.body.append(progress);
})();
