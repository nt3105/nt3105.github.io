# Thanh điều hướng — bản 5

## Giao diện và phạm vi

Theo yêu cầu cuối cùng, bỏ logo `nt. ngân tú.` và khoảng trống bên trái khỏi **header**. Logo cuối trang giữ nguyên. Thanh còn lại căn giữa, rộng tối đa 780 px, các mục có chiều rộng bằng nhau; nút đổi nền cùng chiều cao trên desktop. Nền đen trong suốt nhẹ, viền viên thuốc, khối chọn màu titanium. Chế độ sáng vẫn hoạt động.

Giữ đủ bảy mục và các liên kết cũ: Về mình, Kỹ năng, Dự án, Hành trình, Góc riêng, Ủng hộ, Liên hệ. Theo yêu cầu mobile mới nhất, thanh hiện trực tiếp bốn mục chữ **Về mình, Kỹ năng, Dự án, Liên hệ** và một nút đổi nền ở bên phải. Chỉ nút đổi nền dùng icon mặt trời/mặt trăng, không hiện chữ. Bỏ hamburger và danh sách xổ xuống cũ. Desktop vẫn đủ bảy mục; các phần nội dung tương ứng không bị xóa.

Không thay đổi nội dung, ảnh, nhạc, game, footer hoặc bố cục các phần trong `main`. Không triển khai hay sửa website đang chạy.

## Hiệu ứng thay thế

- Bỏ nền active riêng từng liên kết, gạch sáng bên dưới và hiệu ứng hover cũ.
- Một phần tử trang trí duy nhất trượt giữa các mục, không tạo/xóa lại khi chọn. Thời gian 440 ms, easing đàn hồi nhẹ; hover chỉ đổi sắc chữ.
- Khi bấm nhanh, CSS chuyển hướng từ trạng thái đang chuyển động. Giữ mục vừa bấm trong lúc native anchor đang cuộn qua các mục trung gian.
- Căn lại vị trí đích một lần khi điều hướng ổn định nếu nội dung tải muộn làm lệch anchor; thao tác tay hủy bước căn này.
- Cuộn tay ngắt chuyển động cuộn đến mục và trả quyền chọn mục cho scrollspy. Vùng không có mục menu riêng giữ mục gần nhất thay vì làm mất khối chọn.
- Căn lại vị trí khi đổi kích thước, chuyển desktop/mobile, đổi bố cục hoặc font hoàn tất tải. Dùng requestAnimationFrame để gộp đo/cập nhật; ResizeObserver theo dõi kích thước thực tế. Trong bố cục ổn định, các mục bằng nhau nên phần chuyển chính là transform; không có vòng lặp JavaScript chạy animation liên tục.
- Tôn trọng `prefers-reduced-motion`; khối chọn chuyển ngay khi người dùng yêu cầu giảm chuyển động. Không chặn liên kết mặc định hoặc lịch sử trình duyệt.

## Tệp chạy website đã sửa

| Tệp | Thay đổi |
| --- | --- |
| `index.html` | Bỏ logo header và hamburger; thêm nhãn truy cập cho liên kết; bỏ CSS/JS ghim dropdown cũ và thay bằng bố cục mobile bốn mục chữ. |
| `appearance.css` | Giao diện pill, các mục bằng nhau, khối chọn, sáng/tối, responsive và reduced motion. |
| `script.js` | Khối chọn dùng chung, scrollspy, điều phối bấm/cuộn, đo lại kích thước; focus nút về đầu trang không phụ thuộc logo đã bỏ. |
| `style.css` | Bỏ hiệu ứng active/hover/gạch chân và CSS toggle/dropdown cũ của menu. |
| `enhance.css` | Bỏ ánh sáng gạch chọn, transition chiều cao header và CSS dropdown cũ. |
| `ios-preview.css` | Bỏ ghi đè active cũ không còn dùng. |

Không thêm dependency khi chạy website; intro tự tải các tệp hiện có nên không phải sửa trang intro.

## Kiểm tra

**Kết quả cuối: 53/53 kiểm tra chức năng đạt** — 18 điều hướng, 24 hồi quy website, 11 hiệu ứng/game. Quét axe không ghi nhận vi phạm trong các phạm vi kiểm tra: header desktop/mobile hai nền và 20 lượt cho header, hero, gallery, sáu mục menu game, dialog thành tích. CSS đã sửa không có lỗi parse; JavaScript và script inline qua kiểm tra cú pháp.

Bổ sung/cập nhật tài liệu và kiểm thử: `tests/navigation-check.cjs`, `tests/browser-check.cjs`, các báo cáo JSON, `README.md`, `KIEM-THU.md` và báo cáo này.

Bộ kiểm tra chuyên biệt: `tests/navigation-check.cjs`. Báo cáo máy đọc được: `tests/navigation-results.json`. Kiểm tra cú pháp/phạm vi: `tests/navigation-scope.json`. Báo cáo hồi quy của bản này: `tests/navigation-regression.json`.

- Liên kết, tên mục, hash, Enter, Back, nút về đầu trang; chọn mục theo cuộn.
- Một khối chọn duy nhất và luôn hiện trong lúc đổi mục; chuyển hướng giữa animation, bấm liên tiếp cả khi cuộn thật.
- Khung nhìn 320, 390, 760, 761, 768, 1024, 1440, 1920 px, cả sáng và tối; các mục bằng nhau, không tràn ngang, khối chọn khớp vị trí.
- Resize, chiều ngang điện thoại, đổi kích thước chữ, tải font, chạm, Enter/Tab; bốn mục chữ luôn hiện, không còn khóa cuộn của dropdown.
- Giảm chuyển động, URL có hash, intro handoff; kiểm tra axe cho header desktop và menu mobile ở hai nền.
- Parse các CSS đã sửa, kiểm tra cú pháp JavaScript và script inline, ID trùng, tài nguyên cục bộ lỗi và lỗi JavaScript chưa bắt.
- Đối chiếu với ZIP bản 4: phần `main`, footer, tên/liên kết menu và các tệp ảnh/nhạc giữ nguyên. Chỉ sáu tệp chạy website nêu trên thay đổi.

Chạy server: `python3 dev_server.py --port 8001`. Chạy test trong môi trường đã cài Playwright/Chromium và axe-core:

```sh
node tests/navigation-check.cjs
node tests/browser-check.cjs
node tests/revision-3-check.cjs
node tests/accessibility-check.cjs
```

Các test hỗ trợ `NT_TEST_URL`, `CHROMIUM_PATH`, `NT_TEST_OUTPUT`; bộ navigation hỗ trợ `NT_AXE_PATH` để chỉ đường dẫn `axe.min.js`.

## Giới hạn

Kiểm tra thực hiện bằng Chromium/Playwright, gồm giả lập kích thước và cảm ứng iPhone. Chưa kiểm tra trên thiết bị Android/iPhone thật hoặc Safari thật. Chưa đo bảo đảm 60 FPS trên các thiết bị đích; hiệu năng còn phụ thuộc GPU, trình duyệt và các hiệu ứng nền có sẵn. Kết quả tự động không thay thế kiểm tra thực tế trên mọi thiết bị.
