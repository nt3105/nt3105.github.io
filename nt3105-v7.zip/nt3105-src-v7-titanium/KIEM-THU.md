# Báo cáo kiểm thử — 15/10/2026

Nguồn: commit trước bảo trì `25e9bc464fa525bc7c332f4cdd77ae9300018967`.
Môi trường: Chromium headless qua Playwright, chạy website từ server HTTP cục bộ hỗ trợ Range.

## Kiểm tra bản 5 — mới nhất

**53/53 kiểm tra chức năng đạt** sau khi áp dụng yêu cầu mobile bốn mục chữ và nút sáng/tối chỉ có icon. Đã chạy lại bộ điều hướng, hồi quy website, hiệu ứng chuột/cảm biến giả lập và menu game; quét khả năng truy cập không ghi nhận vi phạm trong phạm vi kiểm tra. Các yêu cầu về sáu kỹ năng, footer, thông báo khóa, chữ ký ntjr và nội dung ảnh/nhạc cũng được đối chiếu.

Chi tiết tệp, phạm vi, cách chạy, các lỗi đã sửa và giới hạn nằm trong [NAVIGATION-UPDATE.md](NAVIGATION-UPDATE.md). Những mục bên dưới ghi lại các bản trước; phần logo header/menu đã được thay theo yêu cầu mới nhất của bản 5.

## Kiểm tra bản 4

- Kiểm tra cú pháp `snake.js`; xác nhận cả hai vị trí thông báo được thay đúng câu “Tài khoản của bạn đã bị khóa.”.
- Kiểm tra sáu thẻ kỹ năng đúng danh sách, footer ba công nghệ, logo `nt.` / `ngân tú.` không còn dòng phụ và khung ngoài.
- Kiểm tra cả hai nền ở 320, 390, 768, 1100, 1440 px: không tràn ngang, logo nằm trong khung; nút menu điện thoại và liên kết về đầu trang hoạt động.
- Intro chuyển sang trang có logo và danh sách kỹ năng mới.
- Không ghi nhận lỗi JavaScript chưa bắt trong các lượt kiểm tra này. Báo cáo: `tests/revision-4.json`.
- Các kết quả 35/35 và axe bên dưới thuộc bản 3; bản 4 chỉ thay nội dung và kiểu logo nên chạy kiểm tra tập trung ở các phần này.

## Kết quả bản 3

**35/35 nhóm kiểm tra chức năng đạt**: 24 kiểm tra hồi quy và 11 kiểm tra bản 3. Chi tiết ở `tests/results.json` và `tests/revision-3.json`.

- Không trùng ID, không có anchor nội bộ trỏ tới phần bị thiếu; ảnh hero/gallery tải được.
- Nút đổi nền sáng/tối, trạng thái hỗ trợ đọc màn hình, màu thanh trình duyệt và lưu lựa chọn sau tải lại.
- Thẻ Hello world đi đúng góc code, ba tab C/Objective-C/Swift và kết quả mẫu hoạt động.
- Cả sáu bài nhạc tải/giải mã/phát được; dừng/phát, âm lượng và tua hoạt động; thẻ hero khớp player. Khôi phục tự phát; khi autoplay bị chặn, nhạc bắt đầu sau tương tác hợp lệ. Sau khi chủ động dừng/tắt, cuộn và click không bật lại.
- Gallery kéo chuột/vuốt cảm ứng, nút trước/sau; kéo không mở nhầm ảnh; lightbox đổi ảnh bằng bàn phím, Escape và trả focus.
- Snake thực sự ăn mồi và ghi điểm khi kết thúc; bật/tắt âm thanh nhớ sau tải lại; tạm dừng/tiếp tục; các preset thường/tự cày/nhanh/bất tử/hỗn loạn.
- Bảng điểm trong game tạm dừng ván, dùng đúng dữ liệu hiện có, lọc được; đóng trả focus về game. Không còn mục thành tích ngoài trang.
- Bố cục, header, hero và bảng điểm ở **320, 375, 390, 430, 768, 1366, 1920 px**, cả nền sáng lẫn nền tối; không tràn ngang trang/dialog trong các trường hợp kiểm tra.
- Form liên hệ kiểm tra dữ liệu và tạo liên kết soạn email đúng; không gửi email trong quá trình test.
- Khi trình duyệt chặn storage, các nút đổi nền và bảng điểm vẫn dùng được.
- Đường vào intro thực tế chuyển sang source mới, giữ lựa chọn nền sáng, dùng chung audio giữa intro và trang chính, có cơ chế tự phát và fallback qua tương tác.
- Không có lỗi JavaScript chưa bắt hoặc HTTP lỗi từ tài nguyên cục bộ trong bộ kiểm tra cuối.

## Kiểm tra riêng cho bản chỉnh lần 2

- Ảnh chân dung là hình tròn, chỉ có chữ ký `ntjr`, đã bỏ tên và câu chú thích; không còn nhãn địa điểm cạnh ảnh. Căn ảnh `50% 92%`, bỏ phóng ảnh để thấy bó hoa.
- Gallery giữ bốn ảnh/crop/bố cục; tiêu đề đúng nội dung yêu cầu.
- Chỉ tồn tại một bảng điểm trong dialog game; lối tắt ở hero và bộ tìm nhanh vẫn mở được bảng.
- Nút menu tròn có kéo, không mở nhầm khi kéo, lưu/khôi phục vị trí và mở đúng menu gốc.
- Kiểm tra giá trị chuyển động thực sự thay đổi theo thời gian; gallery xuất hiện/nghiêng theo chuột; tùy chọn giảm chuyển động dừng hiệu ứng.

- Kiểm tra riêng trình duyệt cho phép autoplay: nhạc chạy ngay khi mở trang; cả tạm dừng và tắt nhạc đều được giữ khi cuộn/click tiếp. Trình duyệt chặn autoplay được kiểm tra qua nhánh phát sau tương tác.

## Kiểm tra riêng cho bản chỉnh lần 3

- Di chuyển chuột thực sự thay đổi phép nghiêng của hero và gallery bằng engine cũ; cuộn qua gallery rồi quay lại gọi đúng hiệu ứng hiện từ trên của source cũ.
- Giả lập iPhone 13 trong Chromium, phát sự kiện `DeviceOrientationEvent` với hai góc đối nhau: hero/gallery phản hồi đổi góc nghiêng. Đây là kiểm tra đường xử lý cảm biến bằng dữ liệu giả lập, không phải thử cảm biến phần cứng/Safari thực tế.
- Đổi ba màu/lưới cập nhật dữ liệu canvas; lưu lựa chọn sau tải lại. Lưu/dùng cấu hình khôi phục cờ hỗ trợ, nhân điểm, màu/lưới; reset giữ điểm và bản cấu hình đã lưu.
- Menu giữ kiểu cũ một cột, kiểm tra tất cả sáu mục ở 320×568, 390×844, 768×1024, 844×390 và 1440×900; không tràn ngang, menu nằm trong viewport, phần nội dung/thanh mục cuộn được khi thiếu chỗ. Đã sửa vị trí menu trên màn hình ngang thấp.
- Mũi tên bàn phím đổi mục; nút Xong đóng và trả focus. Chỉ mẫu đang chọn có dấu kiểm.
- Storage bị chặn: lưu/dùng cấu hình trong phiên vẫn hoạt động và thông báo đúng giới hạn lưu trữ.
- Intro tải được CSS/JS menu mới đúng thứ tự. Có thể mở lại thông báo hiệu ứng gốc.

## Kiểm tra bổ sung

- 20 lượt axe (header, hero, gallery, sáu mục menu, dialog điểm × hai chế độ màu): **0 vi phạm tự động** trong phạm vi đã quét. Xem `tests/accessibility.json`.
- Menu Snake nhận/trả focus đúng; kiểm tra nút hướng cảm ứng và canvas không tiếp tục cập nhật khi đang mở bảng điểm.
- Kiểm tra cú pháp JavaScript của các file và script inline; không phát hiện lỗi cú pháp.
- Đối chiếu với commit gốc: toàn bộ ảnh/nhạc và các stylesheet/script không thuộc phần sửa giữ nguyên.
- Đã xem ảnh chụp desktop/mobile và sửa lỗi navbar tablet, thẻ kính sau thay đổi viewport, vị trí mặc định của nút menu tròn trên điện thoại, tương phản chữ trên nền sáng.

## Giới hạn

Kiểm tra cảm ứng dùng giả lập Chromium, chưa chạy trên iPhone/Safari hoặc trình duyệt Facebook thực. Các liên kết mạng xã hội và dịch vụ QR/email bên ngoài không được kiểm chứng đầu cuối; không thực hiện chuyển tiền hay gửi tin nhắn. Không khẳng định website hoàn toàn không còn lỗi trong mọi môi trường.
