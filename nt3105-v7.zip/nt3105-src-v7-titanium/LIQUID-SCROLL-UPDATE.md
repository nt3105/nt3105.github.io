# Bản 6 — Liquid Glass Navigation & Titanium Scroll Motion

Đã sửa trực tiếp source. Không push, deploy hoặc cập nhật website chính thức.

## Thay đổi

- Menu giữ nguyên bảy liên kết desktop, bốn mục chữ mobile và icon sáng/tối. Một khối chọn duy nhất, nền kính titanium, trượt bằng transform trong 480 ms với cubic-bezier(0.22, 1, 0.36, 1). Bỏ animation width/height và các quy tắc mobile cũ bị ghi đè; chỉnh lại lề nhãn Liên hệ.
- Thay các observer reveal một lần, chữ trượt cũ và bộ replay khi cuộn lên bằng một bộ điều phối IntersectionObserver có vùng đệm 96 px để tái kích hoạt khi ra hẳn màn hình.
- Tiêu đề h2 ghép từng ký tự tiếng Việt: 720 ms/ký tự, cách nhau 24 ms, dịch nhẹ và giảm blur. Lớp chữ trang trí aria-hidden đo theo vị trí chữ gốc; giữ chữ gốc để chọn/copy và trình đọc màn hình. Lớp tạm được dọn sau hiệu ứng hoặc khi resize/đổi font/giảm chuyển động.
- Card hiện trong 740 ms, stagger 100 ms; ảnh đi từ trái/phải 24 px; văn bản đi lên 20 px và giảm blur 5 px.
- Ánh sáng trên các đường phân cách sẵn có chạy trong 1.3 giây; thanh kỹ năng sẵn có mở bằng scaleX trong 820 ms, giữ nguyên dữ liệu và chiều rộng đích. Thanh đọc trang có sẵn được thu mảnh còn 2 px.
- Bỏ parallax cuộn nền cũ. Giữ nghiêng theo chuột/cảm biến, hover, click, gallery, nhạc, game và các nội dung hiện tại.
- Nội dung mặc định luôn hiện. Không dùng class ẩn vĩnh viễn chờ JavaScript. Reduced Motion/chế độ ít hiệu ứng bỏ qua và hủy hiệu ứng mới.

## File chạy website đã sửa

1. `appearance.css`: giao diện menu và transform highlight.
2. `script.js`: tinh chỉnh phép đo menu, thay hệ thống reveal và kinetic typography.
3. `style.css`: bỏ CSS reveal/chữ trượt cũ.
4. `enhance.css`: bỏ stagger/progress/icon spring cũ, thêm lớp trình bày hiệu ứng mới.
5. `enhance.js`: bỏ parallax cuộn nền; giữ engine chuột/cảm biến.
6. `selected.css`: bỏ reveal gallery cũ không còn dùng.
7. `polish.css`: bỏ quy tắc reduced-motion của hệ thống reveal đã thay.

`index.html`, nội dung, ảnh và các liên kết không chỉnh sửa trong bản này. Các tệp test/tài liệu được bổ sung hoặc cập nhật riêng.

## Trạng thái kiểm tra

**Theo yêu cầu mới nhất của bạn, đã dừng kiểm tra và gửi ngay bản code hiện tại. Chưa nghiệm thu đầy đủ bản đóng gói.**

Trước khi dừng: bộ menu 18/18 đạt; cú pháp JavaScript và parse CSS đã chạy ở bước trước. Bộ hồi quy có một assertion còn kiểm tra class reveal cũ; assertion đã cập nhật nhưng chưa chạy lại. Bộ kiểm tra cuộn đã chạy một phần; phép so sánh nội dung chọn chữ cần tính xuống dòng do `<br>`, đã sửa assertion nhưng chưa chạy lại. Không dùng kết quả cũ để khẳng định bản 6 hoàn toàn không lỗi.

Các báo cáo JSON bản 3–5 còn trong thư mục tests là lịch sử, không phải kết quả nghiệm thu bản 6. Bộ mới: `tests/scroll-motion-check.cjs`; các bộ điều hướng/hồi quy đã cập nhật theo cơ chế mới.

Chưa kiểm tra đầy đủ các tiêu chí tab nền, lỗi JavaScript giả lập, cảm biến/thiết bị Android hoặc iPhone thật, Safari thật và FPS thực tế. Không khẳng định đạt 60 FPS trên mọi thiết bị.

## Xem demo cục bộ

Giải nén ZIP, mở terminal tại thư mục source và chạy:

```sh
python3 dev_server.py --port 8000
```

Mở `http://127.0.0.1:8000/?intro=off`. Nếu máy dùng lệnh `python` thay vì `python3`, thay tên lệnh tương ứng. Không cần build hay cài thư viện để chạy website.
