/* Titanium Scroll Motion — original demo mechanism, adapted to existing websites.
   1) Add data-tsm-reveal="up|left|right" to existing elements.
   2) Add data-tsm-kinetic to selected existing headings (not whole paragraphs).
   3) Add .tsm-sweep for the 80px growing light bar or .tsm-drawline data-tsm-line for a sweeping divider.
   4) Add .tsm-meter (one inner span) only for EXISTING bars; no made-up metrics.
   5) Optional: data-tsm-scroll-container for internally scrolling demos. Otherwise observes browser window.
   For styling, load titanium-scroll-effects.css. Do not run two scroll animation engines at once.
*/
(function () {
  'use strict';
  const root = document.querySelector('[data-tsm-root]') || document.documentElement;
  if (root.dataset.tsmInitialized === 'yes') return;
  root.dataset.tsmInitialized = 'yes';
  const scroller = root.querySelector('[data-tsm-scroll-container]');
  const reduced = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let enabled = !reduced();
  let observer;
  const targets = Array.from(root.querySelectorAll('[data-tsm-reveal],[data-tsm-kinetic],[data-tsm-line],.tsm-sweep,.tsm-meter'));

  root.querySelectorAll('[data-tsm-kinetic]').forEach(el => {
    if (el.dataset.tsmSplit === 'yes') return;
    const original = el.textContent;
    el.setAttribute('aria-label', original);
    el.textContent = '';
    Array.from(original).forEach((ch, i, letters) => {
      const span = document.createElement('span');
      span.className = 'tsm-letter';
      span.setAttribute('aria-hidden', 'true');
      span.textContent = ch === ' ' ? '\u00a0' : ch;
      span.style.setProperty('--letterdelay', Math.min(i, 22) * 29 + 'ms');
      span.style.setProperty('--letterx', Math.max(-30, Math.min(30, (i - (letters.length - 1) / 2) * 4.2)) + 'px');
      el.appendChild(span);
    });
    el.dataset.tsmSplit = 'yes';
  });

  document.dispatchEvent(new Event('tsm:split-ready'));

  function withinViewport(el) {
    const r = el.getBoundingClientRect();
    const c = scroller ? scroller.getBoundingClientRect() : {top:0,bottom:window.innerHeight};
    return r.bottom > c.top + 85 && r.top < c.bottom - 26;
  }
  function refresh() {
    if (!enabled) { targets.forEach(t => t.classList.add('is-visible')); return; }
    targets.forEach(t => t.classList.toggle('is-visible', withinViewport(t)));
  }
  function observe() {
    if (observer) observer.disconnect();
    if (!enabled) return;
    if (!('IntersectionObserver' in window)) { targets.forEach(t => t.classList.add('is-visible')); return; }
    observer = new IntersectionObserver(entries => {
      entries.forEach(entry => entry.target.classList.toggle('is-visible', entry.isIntersecting));
    }, {root:scroller || null, rootMargin:'-70px 0px -8% 0px', threshold:0.01});
    targets.forEach(t => observer.observe(t));
  }
  function setMotion(on) {
    enabled = Boolean(on) && !reduced() && root.dataset.fx !== 'calm' && ('IntersectionObserver' in window);
    root.classList.toggle('tsm-no-motion', !enabled);
    if (!enabled) { if (observer) observer.disconnect(); targets.forEach(t => t.classList.add('is-visible')); }
    else { targets.forEach(t => t.classList.remove('is-visible')); observe(); refresh(); }
    const toggle = root.querySelector('[data-tsm-toggle]');
    if (toggle) {toggle.textContent = enabled?'Motion ON':'Motion OFF';toggle.setAttribute('aria-pressed',String(enabled));}
  }
  window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', () => setMotion(true));
  new MutationObserver(() => setMotion(true)).observe(root, {attributes:true, attributeFilter:['data-fx']});

  root.classList.add('tsm-ready');
  setMotion(enabled);
  const toggle = root.querySelector('[data-tsm-toggle]');
  if (toggle) toggle.addEventListener('click', () => setMotion(!enabled));

  // The original demo's slim scrolling progress bar.
  const progress = root.querySelector('.tsm-scroll-progress > span');
  const scrollTarget = scroller || window;
  let raf = 0;
  function updateProgress() {
    if (!progress) return;
    const doc = document.documentElement;
    const pos = scroller ? scroller.scrollTop : window.scrollY;
    const max = scroller ? scroller.scrollHeight - scroller.clientHeight : doc.scrollHeight - window.innerHeight;
    progress.style.width = (max > 0 ? Math.min(100,Math.max(0,pos/max*100)) : 0) + '%';
  }
  scrollTarget.addEventListener('scroll', () => {
    if (raf) return;
    raf = window.requestAnimationFrame(() => {updateProgress();raf=0;});
  }, {passive:true});
  updateProgress();
  window.addEventListener('resize', () => {updateProgress();refresh();}, {passive:true});
})();
