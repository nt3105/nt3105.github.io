> **Bản 9 — chuyển động theo cuộn:** tiêu đề 3D, mở ảnh bằng mặt nạ, chiều sâu liên tục ở hero/gallery và khóa cache mới. Xem [MOTION-V9.md](MOTION-V9.md). Chưa chạy thử/kiểm thử theo yêu cầu. ZIP tải về không tự cập nhật website đang hoạt động.

> **Bản 8 — NTJR Motion:** chuyển động toàn trang đã được thiết kế lại theo yêu cầu mới. Xem [MOTION-V8.md](MOTION-V8.md). Chưa chạy thử/kiểm thử theo yêu cầu; các báo cáo cũ bên dưới là lịch sử.

> **Bản 6 — 16/10/2026:** menu Liquid Glass và Titanium Scroll Motion. Đã dừng kiểm tra thêm theo yêu cầu của bạn; bản này chưa nghiệm thu đầy đủ. Xem [LIQUID-SCROLL-UPDATE.md](LIQUID-SCROLL-UPDATE.md). Các kết quả bản 5 bên dưới là lịch sử.

# NT3105 — Bản chỉnh lần 5: thanh điều hướng viên thuốc

Bản này dựa trên commit `25e9bc464fa525bc7c332f4cdd77ae9300018967` của repository `nt3105/nt3105.github.io` — trước khi bật bảo trì. Đây là source đầy đủ để chạy thử; chưa được push hoặc triển khai lên GitHub Pages.

## Mới nhất — lần 5

Thanh điều hướng gọn ở giữa, bỏ logo header theo vùng khoanh đỏ, các mục chia đều và khối chọn trượt 440 ms. Desktop giữ đủ bảy mục; mobile hiện **Về mình, Kỹ năng, Dự án, Liên hệ** bằng chữ và nút đổi nền chỉ có icon ở bên phải. Những điều chỉnh bản 5 này thay thế mô tả header/menu của các bản trước.

Xem [NAVIGATION-UPDATE.md](NAVIGATION-UPDATE.md) để biết phạm vi, danh sách tệp, kiểm tra và giới hạn. Các thay đổi trước về ảnh, nhạc, gallery, game, kỹ năng, footer và thông báo vẫn được giữ.

## Thay đổi lần 4

- Thông báo giới hạn điểm của ván tùy chỉnh đổi thành “Tài khoản của bạn đã bị khóa.” ở toast và màn hình thông báo trong game. Chỉ đổi nội dung hiển thị, giữ cơ chế chơi lại hiện có.
- Kỹ năng còn sáu mục: C, C++, HTML, CSS, JavaScript, Git / GitHub. Bỏ ba thẻ Objective-C, Swift và Java.
- Logo đầu/cuối trang dùng ô xanh đậm `nt.` và chữ thường `ngân tú.`; bỏ khung ngoài và dòng phụ.
- Footer rút gọn: “Made with HTML, CSS & JavaScript”.

## Đã ghép và chỉnh

- Giữ ảnh chân dung tròn cùng các vòng quỹ đạo như source gốc, căn ảnh xuống dưới để thấy khuôn mặt và bó hoa. Bỏ nhãn địa điểm cạnh ảnh, chỉ giữ chữ ký `ntjr` trong ảnh; bỏ tên và câu chú thích theo yêu cầu cuối.
- Thẻ `Hello, world` và thẻ nhạc nổi chuyển động nhẹ bên ảnh chân dung; thẻ nhạc dùng chung player và danh sách sáu bài có sẵn. Tên bài, ảnh bìa, nút phát/tạm dừng đồng bộ. Khôi phục nhạc tự phát như source cũ: thử phát khi vào web/intro, chờ tương tác nếu trình duyệt chặn. Khi người dùng chủ động tạm dừng hoặc tắt, lướt/chạm trang không tự bật lại.
- Giữ nguyên bố cục, bốn ảnh và cách cắt ảnh gallery. Tiêu đề: “NHỮNG KHOẢNH KHẮC CỦA MÌNH / Một chút ngoài những dòng code.”. Nối lại đúng bộ hiệu ứng gốc `script.js` / `enhance.js`: nghiêng và ánh sáng theo chuột/cảm biến, xuất hiện khi cuộn xuống và hiện lại khi cuộn ngược; vẫn hỗ trợ kéo/vuốt, nút mũi tên và mở ảnh lớn.
- Hàng nút bật/tắt âm thanh và mở bảng thành tích trong Snake. Mở bảng điểm tạm dừng game, giữ dữ liệu và bộ lọc cũ. Đã xóa mục bảng thành tích ngoài trang; các lối tắt mở bảng trong game. Khôi phục nút menu tròn phát sáng, kéo được và nhớ vị trí như bản gốc. Trên điện thoại, vị trí ban đầu nằm cạnh lựa chọn độ khó để không che nút âm thanh.
- Nút mặt trời/mặt trăng ngay trên thanh điều hướng: nền tối và nền trắng ngà, tự lưu lựa chọn trên trình duyệt. Menu điện thoại vẫn hoạt động độc lập. Bảng tinh chỉnh màu cũ vẫn dùng được; sắc nền tùy chỉnh áp dụng cho chế độ tối.
- Hiệu ứng dừng khi khuất màn hình, giảm/tắt khi chọn giảm chuyển động; chuyển động không chặn các nút nhạc hoặc thao tác vuốt ảnh.
- Điều chỉnh tương phản chế độ sáng, bố cục tablet/mobile, focus bàn phím, lỗi đổi hướng quá nhanh và vòng vẽ khi tạm dừng Snake.
- Giữ intro, các phần giới thiệu/dự án/liên hệ/QR, bốn ảnh gốc, sáu bài nhạc và các chế độ chơi cũ.

## Riêng bản chỉnh lần 3

- Ảnh đầu trang và bốn ảnh gallery dùng lại wrapper/engine nghiêng gốc; giữ bố cục và hình đã duyệt. Không dùng hiệu ứng gallery nhẹ riêng của bản 2 nữa.
- Menu giữ kiểu cũ theo yêu cầu mới nhất: nền đen xám, thanh mục bên trái, nút mẫu bo tròn xếp dọc; bỏ bố cục thẻ hai cột. Menu tròn bên ngoài và kéo menu vẫn dùng được.
- Mục **Cài đặt** có ba màu bàn chơi (Ngọc bích, Tinh vân, Hổ phách), bật/tắt lưới, lưu/dùng lại một cấu hình riêng và khôi phục mặc định. Màu/lưới áp dụng lên canvas thật và tự nhớ sau tải lại. Nút lưu cấu hình lưu cả chế độ hỗ trợ, tốc độ, nhân điểm, màu và lưới. Reset không xóa điểm hoặc cấu hình đã lưu.
- Mũi tên bàn phím chuyển mục menu. Nút **Xong** đóng menu, trả focus về nút tròn.
- Trong bảng tinh chỉnh giao diện có nút **Bật lại hiệu ứng chuột / nghiêng máy**, mở lại thông báo gốc nếu trước đó bỏ qua. iPhone cần cho phép cảm biến trong thao tác bấm trực tiếp; dùng HTTPS khi xem trên điện thoại. Tùy chọn giảm chuyển động vẫn được tôn trọng.

## Chạy trên máy

Giải nén, mở terminal trong thư mục source rồi chạy:

```bash
python3 dev_server.py --port 8001
```

Windows có thể dùng `py dev_server.py --port 8001`.

Mở `http://127.0.0.1:8001/`. Muốn bỏ qua intro: `http://127.0.0.1:8001/?intro=off`.

Không cần npm hoặc bước build để dùng website. Server đi kèm hỗ trợ tua nhạc bằng HTTP Range. Mở HTML trực tiếp bằng `file://` không phù hợp để kiểm thử phần intro.

## Các tệp chính đã sửa/thêm

- `index.html`: hero, gallery, hàng công cụ Snake, dialog thành tích, nút đổi nền.
- `script.js`: nối player và lightbox hiện có với giao diện mới.
- `snake.js`: trạng thái âm thanh, tạm dừng, điều khiển hướng, menu, kết thúc ván.
- `intro-3d-demo.html`: tải các thành phần mới khi chuyển từ intro vào trang chính.
- `selected.css`, `selected.js`: giao diện và tương tác các phần được chọn.
- `appearance.css`: nút đổi nền và bảng màu sáng.
- `enhance.js`: giữ engine cảm biến gốc, thêm đường mở lại thông báo cho phép hiệu ứng.
- `game-menu.css`, `game-menu.js`: menu giữ kiểu cũ, cài đặt bàn chơi và lưu cấu hình.
- `dev_server.py`: server xem thử tại máy.
- `tests/`: kiểm tra trình duyệt và báo cáo kết quả.

## Kiểm thử

Xem `KIEM-THU.md`. Bộ kiểm tra bản 3 đã đạt **35/35**, ở 7 chiều rộng từ 320 đến 1920 px. Bản 4 kiểm tra riêng nội dung và bố cục tại 320, 390, 768, 1100, 1440 px, cả hai nền, điều hướng điện thoại và chuyển tiếp intro. Kiểm tra axe cho các thành phần mới ở cả hai giao diện không ghi nhận vi phạm tự động. Kết quả này không thay thế kiểm tra trên thiết bị iPhone/Safari thật.

Để chạy lại test, cài Node.js, Playwright và axe-core trong môi trường phát triển:

```bash
npm install --no-save playwright axe-core
node tests/browser-check.cjs
node tests/revision-3-check.cjs
node tests/accessibility-check.cjs
```

Server cần đang chạy trên cổng 8001. Test mặc định dùng Chromium tại `/usr/bin/chromium`; đặt biến môi trường `CHROMIUM_PATH` nếu Chromium ở vị trí khác. Có thể đổi URL qua `NT_TEST_URL`, thư mục báo cáo qua `NT_TEST_OUTPUT`.

## Ghi chú

- Điểm Snake, âm thanh và giao diện được lưu cục bộ theo trình duyệt; không có bảng xếp hạng trực tuyến.
- Liên hệ chỉ soạn nội dung Gmail/Mail; người dùng tự bấm gửi trong ứng dụng email. QR có số tiền sử dụng dịch vụ VietQR từ source gốc.
- Bản gửi để duyệt giữ `noindex, nofollow` trong HTML. Khi quyết định xuất bản, bỏ thẻ này trong hai trang HTML nếu muốn máy tìm kiếm lập chỉ mục.
- Không có commit, push, PR hay thay đổi website đang chạy trong lần sửa này.
