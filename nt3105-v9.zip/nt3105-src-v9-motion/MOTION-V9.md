# NTJR Motion — bản 9

Bản này thay đổi rõ nhịp và chiều sâu chuyển động so với bản 7/8, theo phản hồi của bạn. Nội dung, ảnh gốc, thứ tự section, menu và chức năng hiện có được giữ nguyên.

## Thay đổi trong mã

- Tiêu đề mở từ góc 3D 65 độ và khoảng dịch chuyển 0,85 em, theo từng ký tự có dấu; thời lượng 1.100 ms, độ trễ theo chữ có giới hạn.
- Thẻ đi vào từ khoảng cách 52–72 px; nhóm dự án/ảnh vào từ hai phía với góc nghiêng và độ trễ 110 ms giữa các thẻ. Vỏ ngoài chạy reveal, lớp bên trong giữ tương tác nghiêng bằng chuột/cảm biến.
- Ảnh kỷ niệm mở bằng mặt nạ từ trên xuống trong khung bo tròn. Khi cuộn dọc hoặc vuốt ngang, ảnh dịch chuyển trong khung theo vị trí cuộn; phóng ảnh 6% để bù mép, caption dịch chuyển độc lập.
- Ảnh chân dung, thẻ Hello world, thẻ nhạc và vòng quỹ đạo dịch chuyển ở các tốc độ khác nhau khi cuộn. Animation nổi và nghiêng cũ vẫn ở lớp riêng.
- Bộ xử lý chiều sâu chỉ đo hai vùng hero/gallery khi gần màn hình, gom đọc hình học trước ghi CSS. Nội suy theo thời gian thực, ngừng yêu cầu frame khi đã bắt kịp vị trí; không can thiệp cuộn gốc hoặc chặn thao tác cảm ứng.
- Tái kích hoạt reveal sau khi nội dung ra khỏi vùng nhìn có đệm 48 px. Giữ nội dung hiện khi tắt hiệu ứng; tôn trọng Reduced Motion và lựa chọn ít hiệu ứng đã lưu.
- Không hủy reveal vì thay đổi chiều cao nhỏ khi thanh địa chỉ Safari co giãn; vẫn kết thúc chuyển động khi thay đổi bề ngang hoặc chiều cao lớn.
- Giữ trạng thái chưa chạy của nội dung khi chuyển tab nền; khi bật lại hiệu ứng, nội dung đang hiện được kích hoạt lại. Đường vào từ intro chờ hoàn tất bàn giao trang.
- Đổi khóa phiên bản tài nguyên thành `motion-9` ở cả index và intro, bao gồm CSS/JS đã sửa từ bản 8, để yêu cầu file mới thay cho cache cũ.

## File mã đã sửa so với bản 8

- `titanium-scroll-effects.css`
- `titanium-scroll-effects.js`
- `titanium-scroll-site.js`
- `index.html` (chỉ đường dẫn tài nguyên)
- `intro-3d-demo.html` (chỉ đường dẫn tài nguyên và selector CSS tương ứng)

Tài liệu: `README.md`, `MOTION-V9.md`.

## Trạng thái bàn giao

Chưa chạy website, trình duyệt, build hoặc kiểm thử bản này, theo yêu cầu của bạn. Mô tả trên là hành vi được viết trong mã, chưa phải kết quả kiểm thử trên iPhone/Android/PC. Các báo cáo kiểm thử cũ trong source không áp dụng cho bản 9.

ZIP chứa toàn bộ source. Nhánh tải GitHub chỉ chứa ZIP và hướng dẫn tải, không thay đổi nhánh website và không deploy. Tải ZIP không tự cập nhật trang `nt3105.github.io`: cần giải nén và mở source mới trong môi trường chạy website của bạn. Nếu thiết bị hoặc cài đặt website đang bật giảm chuyển động, hiệu ứng sẽ được giảm/tắt có chủ đích.
